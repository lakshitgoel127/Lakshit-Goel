<?php
define('USER', 'root');
define('PASSWORD', '');
define('HOST', 'localhost');
define('DATABASE', 'login');
 
try {
    $connection = new PDO("mysql:host=".HOST.";dbname=".DATABASE, USER, PASSWORD);
}
 catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}

session_start();

        $username = trim($_POST["username"]);
        $password = trim($_POST["pass"]);
		
	$query = $connection->prepare("SELECT * FROM register WHERE Email=:username");
    $query->bindParam("username", $username, PDO::PARAM_STR);
    $query->execute();
 
    $result = $query->fetch(PDO::FETCH_ASSOC);
 
    if (!$result) {
        echo '<p class="error">Username password combination is wrong!</p>';
    } else {

            $_SESSION['user_id'] = $result['ID'];
            header('Location: http://localhost/site%201/Login_v4/green/SITE.html');
			
        
    }


?>